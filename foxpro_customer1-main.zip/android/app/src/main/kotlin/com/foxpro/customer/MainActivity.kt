package com.foxpro.customer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
